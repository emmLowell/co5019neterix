def create_ips():
    pass


create_ips()