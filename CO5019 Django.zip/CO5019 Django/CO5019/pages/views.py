from django.shortcuts import render, redirect
from django.contrib.auth.models import User, auth
from django.contrib import  messages
#from .models import Profile
from django.http import HttpResponse

# Create your views here.
def main(request):
    return render(request, 'pages/main.html')

def another_page(request):
    return render(request, 'pages/another_page.html')

def static_page(location: str):
    def do_request(request):
        return render(request, location)
    return do_request


def index(request):
    return HttpResponse("Hello, world. Welcome to the index page.")


# def signup(request):
#     if request.method == 'POST':
#         username = request.POST['username']
#         email = request.POST['email']
#         password = request.POST['password']
#         password2 = request.POST['password2']
#
#         if password == password2 :
#             if User.objects.filter(email = email).exist():
#                 messages.info(request,'Email Taken')
#                 return  redirect('signup')
#             elif User.objects.filter(username= username).exists():
#                 messages.info(request, 'Username Taken')
#                 return redirect('signup')
#             else:
#                 user = User.objects.create_user(username = username, email = email, password= password)
#                 user.save()
#
#                 # log user into the account
#                 # create a profile
#                 user_model = User.objects.get(username = username)
#                 new_profile = Profile.objects.create(user = user_model, id_user = user_model.id)
#                 new_profile.save()
#                 return redirect('pages/signup')
#         else:
#             messages.info(request, 'Password not matching')
#             return redirect('pages/signup')
#
#     else:
#         return render(request, 'pages/signup.html')


def signin(request):
    return render(request, 'pages/signin.html')


# these are the view pages for the questions
def store_credentials(request, user_ip):
    return HttpResponse("You're looking at question %s." % user_ip)


def get_credentials(request, user_ip):
    response = "The owner of this ip is: %s."
    return HttpResponse(response % user_ip)


def add(request, user_ip):
    return HttpResponse("New user added with ip: " % user_ip)