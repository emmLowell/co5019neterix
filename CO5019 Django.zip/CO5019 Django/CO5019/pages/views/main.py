import nmap


def main():
    print( "*********CVE test initiated *************")
    #Setup logic of operation

    db= {"Emmanuel": "127.0.0.1"}

    print("********* Accessing Ips *************")
    result = get_credentials("Emmanuel", db)
    print(result)
    print("********* Running Npm Scans on Ips *************")
    run_scan(result)

    print("********* Storing info Stored *************")

    store_credentials("Arike", "129.0.0.4")

    print("*********CVE test completed*************")



def run_scan(ip):
    nm = nmap.PortScanner();
    nm.scan(ip, '22-443');
    print(nm.scaninfo() )
    print(nm.scanstats())
    print(nm.get_nmap_last_output())




def store_credentials(name, ip):
    # store credentials;; Users and Ips
    credential = {name: ip};
    print(credential)
    #return credential;

def get_credentials(user, db):
    # store credentials;; Users and Ips
    credential = db[user]
    print(credential)
    return credential;


def nmap_scan():
    pass

def store_in_db():
    pass

def generate_report():
    pass

def enable_linux():
    pass

def enable_docker():
    pass


if __name__ == '__main__':
   main()