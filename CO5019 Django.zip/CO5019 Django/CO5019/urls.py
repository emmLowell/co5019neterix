from django.contrib import admin
from django.urls import path, include
from pages.views import main, signin, signup
from pages import urls as page_urls
from database.views import create_ips

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', signin, name='signin'),
    path('', signup, name='signup'),
    path('', main, name='main'),
    path('pages/', include(page_urls)),
    path('test/', create_ips, name='create_ips'),
    path('pages/signup', signup, name='signup'),
    path('pages/signin', signin, name='signin'),
]


# class="bg-gray-100",