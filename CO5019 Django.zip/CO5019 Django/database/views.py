from django import forms
from django.shortcuts import redirect, render
from .models import Ips

class IpsForm(forms.ModelForm):
    class Meta:
        model = Ips
        fields = ['ip', 'user']
        
from django.shortcuts import render

def create_ips(request):
    if request.method == 'POST':
        form = IpsForm(request.POST)
        if form.is_valid():
            form.save()
            redirect('main')
            # Redirect to a success page or do something else
    else:
        form = IpsForm()
    return render(request, 'database/create_ips.html', {'form': form})
