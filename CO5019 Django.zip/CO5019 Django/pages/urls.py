from django.contrib import admin
from django.urls import path, include

from . import views
from .views import *


urlpatterns = [
    #path('', main, name='main'),
    path('another/', static_page("pages/another_page.html"), name='another'),
    path("evenmore/", static_page("pages/evenmore.html")),
    #path("signup/", static_page("pages/signup.html")),
    path('signup', views.signup, name= 'signup'),
    path('signin', views.signin, name = 'signin'),
    path("", views.index, name="index"),
    #path('signin', views.signup, name = 'signin'),

    # ex: /polls/
    path("", views.index, name="index"),
    # ex: /polls/5/
    path("<int:user_ip>/", views.store_credentials, name="store_credentials"),
    # ex: /polls/5/results/
    path("<int:user_ip>/get_credentials/", views.get_credentials, name="get_credentials"),
    # ex: /polls/5/vote/
    path("<int:user_ip>/add/", views.add, name="add"),

]
